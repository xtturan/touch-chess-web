# Touch Chess - Accessible Chess for Visually Impaired

## How to Play
- TAP: Count (1-8 for files/ranks)
- HOLD: Confirm selection
- DOUBLE TAP (when count is 0): Go back

## Audio Feedback
- Quick high click: Tap registered
- Higher tone: Selection confirmed
- Low tone: Illegal move
- Click patterns: Engine move communication